#include<stdio.h>
void main()
{
float r, area;
printf("Enter the radius: ");
scanf("%f", &r);
area = 3.14*r*r;
printf("Area of circle is %f", area);
}
