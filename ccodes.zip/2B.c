#include<stdio.h>
void main()
{
float i, cm;
printf("Enter the length in inches: ");
scanf("%f",&i);
cm = 2.54*i;
printf("The length in centimetre is: %f", cm);
}
