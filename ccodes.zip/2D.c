#include<stdio.h>
void main()
{
int a,b;
int sum, diff, product, quotient;
printf("Enter the 2 numbers: ");
scanf("%d %d", &a, &b);
sum = a + b;
diff = a - b;
product = a*b;
quotient = a/b;

printf("sum is %d, difference is %d, product is %d, and quotient is %d", sum, diff, product, quotient);

}
