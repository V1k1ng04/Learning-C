#include<stdio.h>
void main()
{
    int a,b,c,d,e,f,g;
    a = sizeof(int);
    b = sizeof(char);
    c = sizeof(float);
    d = sizeof(double);
    e = sizeof(long int);
    f = sizeof(short int);
    g = sizeof(long double);
    printf("size of int is %d\n", a);
    printf("size of char is %d\n", b);
    printf("size of float is %d\n", c);
    printf("size of double is %d\n", d);
    printf("size of short int is %d\n", e);
    printf("size of long int is %d\n", f);
    printf("size of double long is %d", g);

}
