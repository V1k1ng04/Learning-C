#include<stdio.h>
void main()
{
    float r, volume, sa;
    printf("Enter the radius: ");
    scanf("%f", &r);
    volume = (4/3)*3.14*r*r*r;
    sa = 4*3.14*r*r;
    printf("Surface area of the sphere is %f\n", sa);
    printf("Volume of the sphere is %f", volume);

}
