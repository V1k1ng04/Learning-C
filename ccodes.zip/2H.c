#include<stdio.h>
void main()
{
    int a,b,c,d;
    float ans1, ans2, ans3, ans4;
    a = 30, b = 10, c = 5, d = 15;
    ans1 = (a+b)*c/d;
    ans2 = ((a+b)*c)/d;
    ans3 = a+(b*c)/d;
    ans4 = (a+b)*(c/d);
    printf("Result of first expression is %f\n", ans1);
    printf("Result of second expression is %f\n", ans2);
    printf("Result of third expression is %f\n", ans3);
    printf("Result of fourth expression is %f", ans4);
}
