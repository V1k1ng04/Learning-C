#include<stdio.h>
void main()
{
int a,b,c,largest;
printf("Enter the 3 different numbers: ");
scanf("%d %d %d", &a, &b, &c);
largest = ((a>b && a>c)?a:(b>c)?b:c);
printf("Largest number = %d\n", largest);
}
