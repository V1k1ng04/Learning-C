#include<stdio.h>
void main()
{int x,y;
printf("Enter the value of x: ");
scanf("%d", &x);

if(x == 0)
    {y = 0;
    printf("The value of y is %d", y);}
else if(x<0)
    {y = -1;
    printf("The value of y is %d", y);}
else
    {
        y = 1;
        printf("The value of y is %d", y);
    }
    }

