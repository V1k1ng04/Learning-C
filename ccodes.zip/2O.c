#include<stdio.h>
void main()
{
    int a,b,c;
    printf("Enter three numbers: ");
    scanf("%d %d %d", &a, &b, &c);
    ((a < b) && (a<c)) ? printf("a is smallest\n"):
        (b<c) ? printf("b is smallest\n"):
            printf("c is smallest\n");
}
