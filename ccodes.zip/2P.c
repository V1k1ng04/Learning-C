#include<stdio.h>
void main()
{
int a,b;
printf("Enter the 2 numbers a and b: ");
scanf("%d %d", &a, &b);
if(a>b)
    {printf("a is greater and its value is: %d", a);}
else
    {printf("b is greater and its value is: %d", b);}
}
